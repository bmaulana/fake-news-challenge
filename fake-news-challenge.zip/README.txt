To run the code, open in your command line:
1) pip install matplotlib
2) pip install numpy
3) pip install nltk
4) pip install tqdm
5) python main.py